package GLPI::Agent::Tools::Screen::Neovo;

use strict;
use warnings;

use parent 'GLPI::Agent::Tools::Screen';

sub manufacturer {
    return "AG Neovo";
}

1;
