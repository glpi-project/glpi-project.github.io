package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.7-git6746f4ee";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2023-03-10 02:40"
];

1;

