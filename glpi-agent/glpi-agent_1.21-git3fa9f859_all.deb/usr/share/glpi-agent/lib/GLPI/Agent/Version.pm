package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.21-git3fa9f859";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-09-26 06:09"
];

1;

