package GLPI::Agent::Task::RemoteInventory::Version;

use strict;
use warnings;

use constant VERSION => "1.2";

1;
