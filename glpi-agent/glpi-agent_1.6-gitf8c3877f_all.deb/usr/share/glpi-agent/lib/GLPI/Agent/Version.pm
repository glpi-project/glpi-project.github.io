package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.6-gitf8c3877f";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2023-07-05 02:41"
];

1;

