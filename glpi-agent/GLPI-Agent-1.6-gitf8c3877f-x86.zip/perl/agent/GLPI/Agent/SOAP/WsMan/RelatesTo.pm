package GLPI::Agent::SOAP::WsMan::RelatesTo;

use strict;
use warnings;

use GLPI::Agent::SOAP::WsMan::Node;

## no critic (ProhibitMultiplePackages)
package
    RelatesTo;

use parent
    'Node';

use constant xmlns  => 'a';

1;
