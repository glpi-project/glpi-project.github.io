package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git9408ea98";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Wed Oct 21 01:33:15 2026 UTC",
    "Built with Strawberry Perl 5.44.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
