package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitdf5004c4";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Wed Oct 28 01:20:16 2026 UTC",
    "Built with Strawberry Perl 5.44.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
