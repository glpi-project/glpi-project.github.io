package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitcb234e4e";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Sat Nov 28 01:18:07 2026 UTC",
    "Built with Strawberry Perl 5.44.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
