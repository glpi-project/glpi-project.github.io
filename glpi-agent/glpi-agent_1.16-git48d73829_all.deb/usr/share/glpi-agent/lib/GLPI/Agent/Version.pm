package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.16-git48d73829";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2025-12-19 02:59"
];

1;

