package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.16-git8ff2b9d5";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2025-12-30 03:02"
];

1;

