package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.16-git48f4c7f0";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2025-12-16 03:00"
];

1;

