package GLPI::Agent::Task::Collect::Version;

use strict;
use warnings;

use constant VERSION => "3.0";

1;
