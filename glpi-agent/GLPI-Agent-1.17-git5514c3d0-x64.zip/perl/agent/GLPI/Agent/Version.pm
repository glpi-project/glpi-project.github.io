package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.17-git5514c3d0";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Sat Feb 28 03:19:34 2026 UTC",
    "Built with Strawberry Perl 5.42.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
