package GLPI::Agent::Task::NetDiscovery::Version;

use strict;
use warnings;

use constant VERSION => "5.1";

1;
