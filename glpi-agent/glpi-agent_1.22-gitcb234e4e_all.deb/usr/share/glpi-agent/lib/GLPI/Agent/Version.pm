package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitcb234e4e";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-11-28 01:18"
];

1;

