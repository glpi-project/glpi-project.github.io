package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.6-gitbad7806d";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2023-06-28 02:41"
];

1;

