package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.20-git81801ac4";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-09-04 05:52"
];

1;

