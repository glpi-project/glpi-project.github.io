package GLPI::Agent::Task::ESX::Version;

use strict;
use warnings;

use constant VERSION => "2.14";

1;
