package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.21-git41c99b80";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-10-03 06:30"
];

1;

