package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.6-gitf8c3877f";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Wed Jul  5 02:45:27 2023 UTC",
    "Built with Strawberry Perl 5.36.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
