package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.17-git63359474";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Thu Feb 26 03:41:01 2026 UTC",
    "Built with Strawberry Perl 5.42.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
