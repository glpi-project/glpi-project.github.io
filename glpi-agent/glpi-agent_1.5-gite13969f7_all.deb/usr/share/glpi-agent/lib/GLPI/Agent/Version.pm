package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.5-gite13969f7";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2022-07-12 03:34"
];

1;

