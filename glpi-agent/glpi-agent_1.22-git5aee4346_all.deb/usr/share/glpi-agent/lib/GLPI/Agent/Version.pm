package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git5aee4346";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-11-20 01:16"
];

1;

