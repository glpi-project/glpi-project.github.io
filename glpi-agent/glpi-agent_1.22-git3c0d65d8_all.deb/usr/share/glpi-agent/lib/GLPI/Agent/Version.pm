package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git3c0d65d8";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-11-13 01:15"
];

1;

