package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.6-gitbad7806d";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Wed Jun 28 02:47:06 2023 UTC",
    "Built with Strawberry Perl 5.36.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
