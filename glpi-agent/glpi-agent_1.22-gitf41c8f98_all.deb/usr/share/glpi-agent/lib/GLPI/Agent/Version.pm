package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitf41c8f98";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-11-07 01:16"
];

1;

