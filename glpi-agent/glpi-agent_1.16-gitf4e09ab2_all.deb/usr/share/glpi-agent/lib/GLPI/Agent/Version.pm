package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.16-gitf4e09ab2";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-01-15 03:05"
];

1;

