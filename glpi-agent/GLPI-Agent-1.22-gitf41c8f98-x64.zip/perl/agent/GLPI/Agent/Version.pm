package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitf41c8f98";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Sat Nov  7 01:17:14 2026 UTC",
    "Built with Strawberry Perl 5.44.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
