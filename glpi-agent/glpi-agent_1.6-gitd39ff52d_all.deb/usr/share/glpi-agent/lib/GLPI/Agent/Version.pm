package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.6-gitd39ff52d";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2023-07-01 02:50"
];

1;

