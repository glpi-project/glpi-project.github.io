package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git3c0d65d8";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Fri Nov 13 01:15:46 2026 UTC",
    "Built with Strawberry Perl 5.44.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
