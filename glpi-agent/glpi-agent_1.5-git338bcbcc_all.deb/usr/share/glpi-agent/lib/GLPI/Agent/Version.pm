package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.5-git338bcbcc";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2022-07-16 03:10"
];

1;

