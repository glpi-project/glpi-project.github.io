package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git9408ea98";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-10-21 01:32"
];

1;

