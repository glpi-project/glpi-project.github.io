#!/usr/bin/perl

use strict;
use warnings;
use utf8;
use lib 't/lib';

use English qw(-no_match_vars);
use Test::Deep qw(cmp_deeply);
use Test::MockModule;
use Test::More;

use GLPI::Test::Utils;
use GLPI::Agent::Tools;

BEGIN {
    # use mock modules for non-available ones
    push @INC, 't/lib/fake/windows' if $OSNAME ne 'MSWin32';
}

use Config;
# check thread support availability
if (!$Config{usethreads} || $Config{usethreads} ne 'define') {
    plan skip_all => 'thread support required';
} elsif ($OSNAME eq 'MSWin32' && exists($ENV{GITHUB_ACTIONS})) {
    plan skip_all => 'Not working on github action windows image';
}

# REG_SZ & REG_DWORD provided by even faked Win32::TieRegistry module
Win32::TieRegistry->require();
Win32::TieRegistry->import('REG_DWORD', 'REG_SZ');

my %tests = (
    7 => [
        {
            dns         => '192.168.0.254',
            IPMASK      => '255.255.255.0',
            IPGATEWAY   => '192.168.0.254',
            MACADDR     => 'F4:6D:04:97:2D:3E',
            STATUS      => 'Up',
            IPDHCP      => '192.168.0.254',
            IPSUBNET    => '192.168.0.0',
            DESCRIPTION => 'Connexion au réseau local',
            IPADDRESS   => '192.168.0.1',
            VIRTUALDEV  => 0,
            SPEED       => 100,
            PNPDEVICEID => 'PCI\VEN_10EC&DEV_8168&SUBSYS_84321043&REV_06\4&87D54EE&0&00E5',
            PCIID       => '10EC:8168:8432:1043',
            GUID        => '{442CDFAD-10E9-45B6-8CF9-C829034793B0}',
            MANUFACTURER => 'Realtek',
            MODEL       => 'Realtek PCIe GBE Family Controller',
        },
        {
            dns         => '192.168.0.254',
            IPMASK6     => 'ffff:ffff:ffff:ffff::',
            MACADDR     => 'F4:6D:04:97:2D:3E',
            STATUS      => 'Up',
            IPADDRESS6  => 'fe80::311a:2127:dded:6618',
            IPSUBNET6   => 'fe80::',
            DESCRIPTION => 'Connexion au réseau local',
            VIRTUALDEV  => 0,
            SPEED       => 100,
            PNPDEVICEID => 'PCI\VEN_10EC&DEV_8168&SUBSYS_84321043&REV_06\4&87D54EE&0&00E5',
            PCIID       => '10EC:8168:8432:1043',
            GUID        => '{442CDFAD-10E9-45B6-8CF9-C829034793B0}',
            MANUFACTURER => 'Realtek',
            MODEL       => 'Realtek PCIe GBE Family Controller',
        },
        {
            dns         => undef,
            MACADDR     => '00:26:83:12:FB:0B',
            STATUS      => 'Down',
            DESCRIPTION => 'Connexion réseau Bluetooth',
            VIRTUALDEV  => 0,
            PNPDEVICEID => 'BTH\MS_BTHPAN\7&42D85A8&0&2',
            GUID        => '{DDE01862-B0C0-4715-AF6C-51D31172EBF9}',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Périphérique Bluetooth (réseau personnel)',
        },
    ],
    'vpn-down' => [            {
                DESCRIPTION => 'Ethernet 2',
                GUID        => '{4CB24B28-7970-4249-8D9F-C1B75E98DF09}',
                MACADDR     => '00:FE:00:00:00:01',
                MTU         => 1500,
                PNPDEVICEID => 'ROOT\\NET\\0000',
                SPEED       => 100,
                STATUS      => 'Down',
                TYPE        => 'ethernet',
                VIRTUALDEV  => 1,
                dns         => undef,
                MANUFACTURER => 'Fortinet',
                MODEL       => 'Fortinet Virtual Ethernet Adapter (NDIS 6.30)',
            },
            {
                DESCRIPTION => 'Ethernet 4',
                DNSDomain   => 'sample.org',
                GUID        => '{B039FEDD-F8DC-4A5D-98BF-CCF184B86F65}',
                IPADDRESS   => '10.178.0.178',
                IPDHCP      => '10.178.0.1',
                IPGATEWAY   => '10.178.0.1',
                IPMASK      => '255.255.255.0',
                IPSUBNET    => '10.178.0.0',
                MACADDR     => '83:00:00:09:00:FD',
                MTU         => 1500,
                PNPDEVICEID => 'USB\\VID_0BDA&PID_8153\\001000001',
                SPEED       => 1000,
                STATUS      => 'Up',
                TYPE        => 'ethernet',
                VIRTUALDEV  => 0,
                dns         => '127.0.0.1',
                MANUFACTURER => 'Realtek',
                MODEL       => 'Realtek USB GbE Family Controller',
            },
            {
                DESCRIPTION => 'Ethernet 4',
                DNSDomain   => 'sample.org',
                GUID        => '{B039FEDD-F8DC-4A5D-98BF-CCF184B86F65}',
                IPADDRESS6  => 'fe80::3cdb:7f48:22b1:4ec4',
                IPMASK6     => 'ffff:ffff:ffff:ffff::',
                IPSUBNET6   => 'fe80::',
                MACADDR     => '83:00:00:09:00:FD',
                MTU         => 1500,
                PNPDEVICEID => 'USB\\VID_0BDA&PID_8153\\001000001',
                SPEED       => 1000,
                STATUS      => 'Up',
                TYPE        => 'ethernet',
                VIRTUALDEV  => 0,
                dns         => '127.0.0.1',
                MANUFACTURER => 'Realtek',
                MODEL       => 'Realtek USB GbE Family Controller',
            },
            {
                DESCRIPTION => 'Wi-Fi',
                GUID        => '{31DEAC2D-2194-4511-AA54-787CD1765558}',
                MACADDR     => '45:00:00:00:FF:14',
                MTU         => 1500,
                PCIID       => '8086:A0F0:4070:8086',
                PNPDEVICEID => 'PCI\\VEN_8086&DEV_A0F0&SUBSYS_40708086&REV_20\\3&11583659&0&A3',
                SPEED       => 144,
                STATUS      => 'Down',
                TYPE        => 'wifi',
                VIRTUALDEV  => 0,
                dns         => undef,
                MANUFACTURER => 'Intel',
                MTU         => 1500,
                MODEL       => 'Intel(R) Wi-Fi 6 AX201 160MHz',
            },
            {
                DESCRIPTION => 'Connexion réseau Bluetooth',
                GUID        => '{C6D0BB76-E0FA-4780-AFA2-78AC0E1849A0}',
                MACADDR     => '45:00:00:00:FD:12',
                MTU         => 1500,
                PNPDEVICEID => 'BTH\\MS_BTHPAN\\6&2f62bcfe&0&2',
                SPEED       => 3,
                STATUS      => 'Down',
                TYPE        => 'ethernet',
                VIRTUALDEV  => 1,
                dns         => undef,
                MANUFACTURER => 'Microsoft',
                MODEL       => 'Bluetooth Device (Personal Area Network)',
            },
            {
                DESCRIPTION => 'Ethernet 3',
                GUID        => '{E68EB6CC-9580-4151-80E2-2DA4DC27AF81}',
                MACADDR     => undef,
                MTU         => 1392,
                PNPDEVICEID => 'ROOT\\NET\\0001',
                SPEED       => 100000,
                STATUS      => 'Down',
                TYPE        => 'ethernet',
                VIRTUALDEV  => 1,
                dns         => undef,
                MANUFACTURER => 'Fortinet Inc',
                MODEL       => 'Fortinet SSL VPN Virtual Ethernet Adapter',
            }
    ],
    'vpn-up' => [
        {
            DESCRIPTION => 'Ethernet 2',
            GUID        => '{4CB24B28-7970-4249-8D9F-C1B75E98DF09}',
            MACADDR     => '00:FE:00:00:00:01',
            MTU         => 1500,
            PNPDEVICEID => 'ROOT\\NET\\0000',
            SPEED       => 100,
            STATUS      => 'Down',
            TYPE        => 'ethernet',
            VIRTUALDEV  => 1,
            dns         => undef,
            MANUFACTURER => 'Fortinet',
            MODEL       => 'Fortinet Virtual Ethernet Adapter (NDIS 6.30)',
        },
        {
            DESCRIPTION => 'Ethernet 4',
            GUID        => '{B039FEDD-F8DC-4A5D-98BF-CCF184B86F65}',
            MACADDR     => '83:00:00:09:00:FD',
            MTU         => 1500,
            PNPDEVICEID => 'USB\\VID_0BDA&PID_8153\\001000001',
            STATUS      => 'Down',
            TYPE        => 'ethernet',
            VIRTUALDEV  => 0,
            dns         => undef,
            MANUFACTURER => 'Realtek',
            MODEL       => 'Realtek USB GbE Family Controller',
        },
        {
            DESCRIPTION => 'Wi-Fi',
            GUID        => '{31DEAC2D-2194-4511-AA54-787CD1765558}',
            IPADDRESS   => '192.168.0.254',
            IPDHCP      => '192.168.0.102',
            IPGATEWAY   => '192.168.0.102',
            IPMASK      => '255.255.255.0',
            IPSUBNET    => '192.168.0.0',
            MACADDR     => '45:00:00:00:FF:14',
            MTU         => 1500,
            PCIID       => '8086:A0F0:4070:8086',
            PNPDEVICEID => 'PCI\\VEN_8086&DEV_A0F0&SUBSYS_40708086&REV_20\\3&11583659&0&A3',
            SPEED       => 144,
            STATUS      => 'Up',
            TYPE        => 'wifi',
            VIRTUALDEV  => 0,
            dns         => '127.0.0.1',
            MANUFACTURER => 'Intel',
            MODEL       => 'Intel(R) Wi-Fi 6 AX201 160MHz',
        },
        {
            DESCRIPTION => 'Wi-Fi',
            GUID        => '{31DEAC2D-2194-4511-AA54-787CD1765558}',
            IPADDRESS6  => 'fe80::3a27:1bd1:1148:0d87',
            IPMASK6     => 'ffff:ffff:ffff:ffff::',
            IPSUBNET6   => 'fe80::',
            MACADDR     => '45:00:00:00:FF:14',
            MTU         => 1500,
            PCIID       => '8086:A0F0:4070:8086',
            PNPDEVICEID => 'PCI\\VEN_8086&DEV_A0F0&SUBSYS_40708086&REV_20\\3&11583659&0&A3',
            SPEED       => 144,
            STATUS      => 'Up',
            TYPE        => 'wifi',
            VIRTUALDEV  => 0,
            dns         => '127.0.0.1',
            MANUFACTURER => 'Intel',
            MODEL       => 'Intel(R) Wi-Fi 6 AX201 160MHz',
        },
        {
            DESCRIPTION => 'Connexion réseau Bluetooth',
            GUID        => '{C6D0BB76-E0FA-4780-AFA2-78AC0E1849A0}',
            MACADDR     => '45:00:00:00:FD:12',
            MTU         => 1500,
            PNPDEVICEID => 'BTH\\MS_BTHPAN\\6&2f62bcfe&0&2',
            SPEED       => 3,
            STATUS      => 'Down',
            TYPE        => 'ethernet',
            VIRTUALDEV  => 1,
            dns         => undef,
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Bluetooth Device (Personal Area Network)',
        },
        {
            DESCRIPTION => 'Ethernet 3',
            GUID        => '{E68EB6CC-9580-4151-80E2-2DA4DC27AF81}',
            IPADDRESS   => '10.177.0.17',
            IPDHCP      => undef,
            IPGATEWAY   => undef,
            IPMASK      => '255.255.255.255',
            IPSUBNET    => '10.177.0.17',
            MACADDR     => '00:00:A0:00:00:01',
            MTU         => 1392,
            PNPDEVICEID => 'ROOT\\NET\\0001',
            SPEED       => 100000,
            STATUS      => 'Up',
            TYPE        => 'ethernet',
            VIRTUALDEV  => 1,
            dns         => '127.0.0.1',
            MANUFACTURER => 'Fortinet Inc',
            MODEL       => 'Fortinet SSL VPN Virtual Ethernet Adapter',
        },
        {
            DESCRIPTION => 'Ethernet 3',
            GUID        => '{E68EB6CC-9580-4151-80E2-2DA4DC27AF81}',
            IPADDRESS6  => 'fe80::485a:6ef8:5cc4:45e1',
            IPMASK6     => 'ffff:ffff:ffff:ffff::',
            IPSUBNET6   => 'fe80::',
            MACADDR     => '00:00:A0:00:00:01',
            MTU         => 1392,
            PNPDEVICEID => 'ROOT\\NET\\0001',
            SPEED       => 100000,
            STATUS      => 'Up',
            TYPE        => 'ethernet',
            VIRTUALDEV  => 1,
            dns         => '127.0.0.1',
            MANUFACTURER => 'Fortinet Inc',
            MODEL       => 'Fortinet SSL VPN Virtual Ethernet Adapter',
        }
    ],
    xp => [
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\MS_PPTPMINIPORT\\0000',
            MACADDR     => '50:50:54:50:30:30',
            STATUS      => 'Down',
            DESCRIPTION => 'Minipuerto WAN (PPTP)',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Minipuerto WAN (PPTP)',
        },
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\MS_PPPOEMINIPORT\\0000',
            MACADDR     => '33:50:6F:45:30:30',
            STATUS      => 'Down',
            DESCRIPTION => 'Minipuerto WAN (PPPOE)',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Minipuerto WAN (PPPOE)',
        },
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\MS_PSCHEDMP\\0000',
            MACADDR     => '26:0F:20:52:41:53',
            STATUS      => 'Down',
            DESCRIPTION => 'Minipuerto del administrador de paquetes',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Minipuerto del administrador de paquetes',
        },
        {
            dns         => '10.36.6.100',
            IPMASK      => '255.255.254.0',
            IPGATEWAY   => '10.36.6.1',
            VIRTUALDEV  => 0,
            PNPDEVICEID => 'PCI\\VEN_14E4&DEV_1677&SUBSYS_3006103C&REV_01\\4&1886B119&0&00E1',
            PCIID       => '14E4:1677:3006:103C',
            MACADDR     => '00:14:C2:0D:B0:FB',
            STATUS      => 'Up',
            IPDHCP      => '10.36.6.100',
            IPSUBNET    => '10.36.6.0',
            DESCRIPTION => 'Conexión de área local 2',
            IPADDRESS   => '10.36.6.30',
            DNSDomain   => 'sociedad.imaginaria.es',
            MANUFACTURER => 'Broadcom',
            MODEL       => 'Broadcom NetXtreme Gigabit Ethernet',
        },
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\MS_PSCHEDMP\\0002',
            MACADDR     => '00:14:C2:0D:B0:FB',
            STATUS      => 'Down',
            DESCRIPTION => 'Minipuerto del administrador de paquetes',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Minipuerto del administrador de paquetes',
        },
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\SYMC_TEEFER2MP\\0000',
            MACADDR     => '00:14:C2:0D:B0:FB',
            STATUS      => 'Down',
            DESCRIPTION => 'Teefer2 Miniport',
            MANUFACTURER => 'Symantec',
            MODEL       => 'Teefer2 Miniport',
        },
        {
            dns         => undef,
            VIRTUALDEV  => 1,
            PNPDEVICEID => 'ROOT\\SYMC_TEEFER2MP\\0002',
            MACADDR     => '26:0F:20:52:41:53',
            STATUS      => 'Down',
            DESCRIPTION => 'Teefer2 Miniport',
            MANUFACTURER => 'Symantec',
            MODEL       => 'Teefer2 Miniport',
        }
    ],
    'loadbalance' => [
        {
            MACADDR     => '20:47:47:90:78:42',
            STATUS      => 'Up',
            dns         => undef,
            DESCRIPTION => 'Ethernet',
            VIRTUALDEV  => 0,
            SPEED       => 1000,
            PNPDEVICEID => 'PCI\VEN_14E4&DEV_165F&SUBSYS_05E51028&REV_00\000020474790784200',
            PCIID       => '14E4:165F:05E5:1028',
            GUID        => '{B1DF2CEB-92D7-4A5A-A548-658D9859D452}',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Broadcom NetXtreme Gigabit Ethernet',
            TYPE        => 'ethernet',
        },
        {
            MACADDR     => '20:47:47:90:78:44',
            STATUS      => 'Up',
            dns         => undef,
            DESCRIPTION => 'Ethernet 2',
            VIRTUALDEV  => 0,
            SPEED       => 1000,
            PNPDEVICEID => 'PCI\VEN_14E4&DEV_165F&SUBSYS_05E51028&REV_00\000020474790784401',
            PCIID       => '14E4:165F:05E5:1028',
            GUID        => '{3FFB051A-B08E-41F6-A9AE-BFEFD0538A59}',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Broadcom NetXtreme Gigabit Ethernet',
            TYPE        => 'ethernet',
        },
        {
            DNSDomain   => 'company.local',
            IPMASK      => '255.255.255.0',
            IPGATEWAY   => '192.168.10.254',
            MACADDR     => '20:47:47:90:78:42',
            STATUS      => 'Up',
            IPSUBNET    => '192.168.10.0',
            IPDHCP      => undef,
            dns         => '192.168.10.250',
            DESCRIPTION => 'LoadBalance',
            IPADDRESS   => '192.168.10.250',
            VIRTUALDEV  => 1,
            SPEED       => 2000,
            PNPDEVICEID => 'COMPOSITEBUS\MS_IMPLAT_MP\{1280DFA8-1A33-437E-88B0-238F0C879599}',
            GUID        => '{1280DFA8-1A33-437E-88B0-238F0C879599}',
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Microsoft Network Adapter Multiplexor Driver',
            TYPE        => 'ethernet',
        }
    ],
    '10-net'    => [
        {
            DESCRIPTION => 'Ethernet 4',
            DNSDomain   => 'contoso.com',
            IPADDRESS   => '192.168.0.2',
            IPDHCP      => '192.168.2.2',
            IPGATEWAY   => '192.168.0.254',
            IPMASK      => '255.255.255.0',
            IPSUBNET    => '192.168.0.0',
            MACADDR     => '00:50:00:00:F3:6D',
            PNPDEVICEID => 'USB\\VID_17E9&PID_4306&MI_05\\7&25c647c&0&0005',
            SPEED       => '1000',
            STATUS      => 'Up',
            VIRTUALDEV  => '0',
            GUID        => '{FD7B5BF5-2E4B-4CA4-0000-F633D86283A1}',
            dns         => '192.168.2.2',
            TYPE        => 'ethernet',
            MTU         => 1500,
            MANUFACTURER => 'DisplayLink Corp.',
            MODEL       => 'DisplayLink Network Adapter NCM',
        },
        {
            DESCRIPTION => 'Ethernet 4',
            DNSDomain   => 'contoso.com',
            IPADDRESS6  => 'fe80::2c1f:9a1f:dedd:699c',
            IPMASK6     => 'ffff:ffff:ffff:ffff::',
            IPSUBNET6   => 'fe80::',
            MACADDR     => '00:50:00:00:F3:6D',
            PNPDEVICEID => 'USB\\VID_17E9&PID_4306&MI_05\\7&25c647c&0&0005',
            SPEED       => '1000',
            STATUS      => 'Up',
            VIRTUALDEV  => '0',
            GUID        => '{FD7B5BF5-2E4B-4CA4-0000-F633D86283A1}',
            dns         => '192.168.2.2',
            TYPE        => 'ethernet',
            MTU         => 1500,
            MANUFACTURER => 'DisplayLink Corp.',
            MODEL       => 'DisplayLink Network Adapter NCM',
        },
        {
            DESCRIPTION => 'vEthernet (Default Switch)',
            IPADDRESS   => '172.17.141.1',
            IPMASK      => '255.255.255.240',
            IPSUBNET    => '172.17.141.0',
            MACADDR     => '00:15:5D:00:00:96',
            PNPDEVICEID => 'ROOT\\VMS_MP\\0000',
            SPEED       => '10000',
            STATUS      => 'Up',
            VIRTUALDEV  => '1',
            GUID        => '{F2274B7D-033B-4FD1-B721-6B1E0E48D26D}',
            TYPE        => 'ethernet',
            IPDHCP      => undef,
            IPGATEWAY   => undef,
            MTU         => 1500,
            dns         => undef,
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Hyper-V Virtual Ethernet Adapter',
        },
        {
            DESCRIPTION => 'vEthernet (Default Switch)',
            IPADDRESS6  => 'fe80::e1b8:381c:382e:d940',
            IPMASK6     => 'ffff:ffff:ffff:ffff::',
            IPSUBNET6   => 'fe80::',
            MACADDR     => '00:15:5D:00:00:96',
            PNPDEVICEID => 'ROOT\\VMS_MP\\0000',
            SPEED       => '10000',
            STATUS      => 'Up',
            VIRTUALDEV  => '1',
            GUID        => '{F2274B7D-033B-4FD1-B721-6B1E0E48D26D}',
            TYPE        => 'ethernet',
            MTU         => 1500,
            dns         => undef,
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Hyper-V Virtual Ethernet Adapter',
        },
        {
            DESCRIPTION => 'Connexion réseau Bluetooth 3',
            MACADDR     => '44:85:00:00:00:5F',
            PNPDEVICEID => 'BTH\\MS_BTHPAN\\6&12f29cde&1&2',
            SPEED       => '3',
            STATUS      => 'Down',
            VIRTUALDEV  => '1',
            GUID        => '{73513F19-5210-45E7-9CB5-6DB761D8291A}',
            TYPE        => 'ethernet',
            MTU         => 1500,
            dns         => undef,
            MANUFACTURER => 'Microsoft',
            MODEL       => 'Bluetooth Device (Personal Area Network)',
        },
        {
            DESCRIPTION => 'Ethernet 9',
            MACADDR     => '00:FF:20:00:00:80',
            PNPDEVICEID => 'ROOT\\NET\\0000',
            SPEED       => '100',
            STATUS      => 'Down',
            VIRTUALDEV  => '1',
            GUID        => '{201DE880-FE07-47BE-0000-A3ABDE40367F}',
            TYPE        => 'ethernet',
            MTU         => 1500,
            dns         => undef,
            MANUFACTURER => 'TAP-Windows Provider V9',
            MODEL       => 'TAP-Windows Adapter V9',
        },
        {
            DESCRIPTION => 'Wi-Fi',
            MACADDR     => '44:85:00:00:00:5B',
            PCIID       => '8086:24F3:0130:8086',
            PNPDEVICEID => 'PCI\\VEN_8086&DEV_24F3&SUBSYS_01308086&REV_3A\\448500000000005B00',
            STATUS      => 'Down',
            VIRTUALDEV  => '0',
            GUID        => '{05CAEBD3-9408-4A3D-0000-EB10577755E3}',
            TYPE        => 'wifi',
            MTU         => 1500,
            dns         => undef,
            MANUFACTURER => 'Intel',
            MODEL       => 'Intel(R) Dual Band Wireless-AC 8260',
        }
    ]
);

# Emulated registry
my %register = (
    'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node' => {
        'TeamViewer' => {
            # Values key begins with a slash
            '/ClientID' => '0x12345678',
            '/Version'  => '12.0.72365',
            # Subkey ends with a slash
            'subkey/'   => {
                '/value' => ''
            }
        }
    },
    'HKEY_LOCAL_MACHINE/CurrentControlSet/Control/Session Manager' => {
        'Environment' => {
            '/TEMP' => '%SystemRoot%\\TEMP',
            '/OS'   => 'Windows_NT',
        }
    },
    'HKEY_USERS/' => {
        'S-1-5-21-2246875202-1293753324-4206800371-500/' => {
            'Software/' => {
                'SimonTatham/' => {
                    'PuTTY/' => {
                        '/Version' => '4.1',
                        'SshHostKeys/' => {
                            '/rsa2@22:192.168.20.32' => '76f523a6eec4ea6b'
                        },
                        '/username' => 'johndoe'
                    }
                },
                'Mozilla/' => {
                    'Firefox/' => {
                        '/Version' => '59.0'
                    }
                }
            }
        },
        'S-1-5-21-2246875202-1293753324-4206800567-500/' => {
            '/DisplayName' => 'Janine',
            'Software/' => {
                'SimonTatham/' => {
                    'PuTTY/' => {
                        '/Version' => '5.2',
                        '/username' => 'jane',
                        'SshHostKeys/' => {
                            '/rsa2@22:192.168.20.54' => 'fdfb3a2eeaa7'
                        }
                    }
                },
                'Mozilla/' => {
                    'Firefox/' => {
                        '/Version' => '62.0',
                        'Configuration/' => {},
                        '/Timeout' => '15'
                    }
                }
            }
        }
    }
);

my %regkey_tests = (
    'nopath' => {
        _expected => undef
    },
    'undef-path' => {
        path      => undef,
        _expected => undef
    },
    'emptypath' => {
        path      => '',
        _expected => undef
    },
    'badroot' => {
        path      => 'HKEY_NOT_A_ROOT/Not_existing_Key_path',
        _expected => undef
    },
    'teamviewer' => {
        path      => 'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node/TeamViewer',
        _expected => bless({
            '/ClientID' => '0x12345678',
            '/Version'  => '12.0.72365',
            'subkey/'    => bless({
                '/value' => ''
            }, 'Win32::TieRegistry')
        }, 'Win32::TieRegistry')
    },
    'environment' => {
        path      => 'HKEY_LOCAL_MACHINE/CurrentControlSet/Control/Session Manager/Environment',
        _expected => bless({
            '/TEMP' => '%SystemRoot%\\TEMP',
            '/OS'   => 'Windows_NT'
        }, 'Win32::TieRegistry')
    }
);

my %regval_tests = (
    'nopath' => {
        _expected => undef
    },
    'undef-path' => {
        path      => undef,
        _expected => undef
    },
    'emptypath' => {
        path      => '',
        _expected => undef
    },
    'badroot' => {
        path      => 'HKEY_NOT_A_ROOT/Not_existing_Key_path',
        _expected => undef
    },
    'teamviewerid' => {
        path      => 'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node/TeamViewer/ClientID',
        _expected => '0x12345678'
    },
    'teamviewer-all' => {
        path      => 'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node/TeamViewer/*',
        _expected => {
            'ClientID' => '0x12345678',
            'Version'  => '12.0.72365',
        }
    },
    'teamviewerid-withtype' => {
        path      => 'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node/TeamViewer/ClientID',
        withtype  => 1,
        _expected => [ '0x12345678', REG_DWORD() ]
    },
    'teamviewer-all-withtype' => {
        path      => 'HKEY_LOCAL_MACHINE/SOFTWARE/Wow6432Node/TeamViewer/*',
        withtype  => 1,
        _expected => {
            'ClientID' => [ '0x12345678', REG_DWORD() ],
            'Version'  => [ '12.0.72365', REG_SZ() ],
        }
    },
    'temp-env' => {
        path      => 'HKEY_LOCAL_MACHINE/CurrentControlSet/Control/Session Manager/Environment/TEMP',
        _expected => '%SystemRoot%\\TEMP'
    },
    'putty_keys' => {
        path      => 'HKEY_USERS/**/Software/SimonTatham/PuTTY/SshHostKeys/*',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/SimonTatham/PuTTY/SshHostKeys/rsa2@22:192.168.20.32'
                => '76f523a6eec4ea6b',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/SimonTatham/PuTTY/SshHostKeys/rsa2@22:192.168.20.54'
                => 'fdfb3a2eeaa7'
        }
    },
    'users_software_versions' => {
        path      => 'HKEY_USERS/**/Software/Mozilla/Firefox/Version',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Version' => '62.0',
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/Mozilla/Firefox/Version' => '59.0'
        }
    },
    'users_softwares_versions' => {
        path      => 'HKEY_USERS/**/Software/**/**/Version',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/SimonTatham/PuTTY/Version' => '4.1',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/SimonTatham/PuTTY/Version' => '5.2',
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/Mozilla/Firefox/Version' => '59.0',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Version' => '62.0'
        }
    },
    'users_software_values' => {
        path      => 'HKEY_USERS/**/Software/**/**/*',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/SimonTatham/PuTTY/Version' => '4.1',
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/SimonTatham/PuTTY/username' => 'johndoe',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/SimonTatham/PuTTY/Version' => '5.2',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Version' => '62.0',
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/Mozilla/Firefox/Version' => '59.0',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/SimonTatham/PuTTY/username' => 'jane',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Timeout' => '15'
        }
    },
    'users_software_values' => {
        path      => 'HKEY_USERS/**/Software/**/Firefox/*',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Version' => '62.0',
            'S-1-5-21-2246875202-1293753324-4206800371-500/Software/Mozilla/Firefox/Version' => '59.0',
            'S-1-5-21-2246875202-1293753324-4206800567-500/Software/Mozilla/Firefox/Timeout' => '15'
        }
    },
    'users_vars' => {
        path      => 'HKEY_USERS/**/*',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800567-500/DisplayName' => 'Janine'
        }
    },
    'users_displayname' => {
        path      => 'HKEY_USERS/**/DisplayName',
        _expected => {
            'S-1-5-21-2246875202-1293753324-4206800567-500/DisplayName' => 'Janine'
        }
    },
    'bad_glob_on_values' => {
        path      => 'HKEY_USERS/**/Software/**/**/**',
        _expected => {}
    },
    'bad_glob_on_values_2' => {
        path      => 'HKEY_USERS/S-1-5-21-2246875202-1293753324-4206800371-500/Software/Mozilla/Firefox/**',
        _expected => undef
    },
    'bad_glob_on_values_3' => {
        path      => 'HKEY_USERS/**/**',
        _expected => {}
    }
);

my $win32_only_test_count = 7;

plan tests =>
    (scalar keys %tests) + $win32_only_test_count +
    (scalar keys %regkey_tests) + (scalar keys %regval_tests);

GLPI::Agent::Tools::Win32->require();
GLPI::Agent::Tools::Win32->use('getInterfaces');

my $module = Test::MockModule->new(
    'GLPI::Agent::Tools::Win32'
);

foreach my $test (keys %tests) {
    $module->mock(
        'getWMIObjects',
        mockGetWMIObjects($test)
    );

    my @interfaces = getInterfaces();
    cmp_deeply(
        \@interfaces,
        $tests{$test},
        "$test sample"
    );
    unless ($tests{$test} && @{$tests{$test}}) {
        Data::Dumper->require();
        my $dumper = Data::Dumper->new([\@interfaces], ["\$tests{$test}"])->Useperl(1)->Indent(1)->Quotekeys(0)->Sortkeys(1)->Pad("        ");
        $dumper->{xpad} = "    ";
        print STDERR "====\nCURRENT RESULTS: ", $dumper->Dump();
    }
}

SKIP: {
    skip 'Avoid windows-emulation based tests on win32',
        (scalar keys %regkey_tests) + (scalar keys %regval_tests)
            if $OSNAME eq 'MSWin32';

    $module->mock(
        '_getRegistryKey',
        sub {
            my (%params) = @_;
            return unless ($params{root} && $params{keyName});
            return unless exists($register{$params{root}});
            my $root = $register{$params{root}};
            return unless exists($root->{$params{keyName}});
            my $key = { %{$root->{$params{keyName}}} };
            # Bless leaf as expected
            map { bless $key->{$_}, 'Win32::TieRegistry' }
                grep { ref($key->{$_}) eq 'HASH' } keys %{$key};
            bless $key, 'Win32::TieRegistry';
            return $key;
        }
    );

    $module->mock(
        '_getRegistryRoot',
        sub {
            my (%params) = @_;
            return unless $params{root};
            my $root;
            if (exists($register{$params{root}})) {
                $root = { %{$register{$params{root}}} };
            } else {
                $root = \%register;
                foreach my $part (split('/',$params{root})) {
                    return unless $root->{$part.'/'};
                    $root = { %{$root->{$part.'/'}} }
                }
            }
            # Bless leaf as expected
            map { bless $root->{$_}, 'Win32::TieRegistry' } grep { m|/$| } keys %{$root};
            bless $root, 'Win32::TieRegistry';
            return $root;
        }
    );

    GLPI::Agent::Tools::Win32->use('getRegistryKey');
    foreach my $test (keys %regkey_tests) {

        my $regkey = getRegistryKey( %{$regkey_tests{$test}} );
        cmp_deeply(
            $regkey,
            $regkey_tests{$test}->{_expected},
            "$test regkey"
        );
    }

    GLPI::Agent::Tools::Win32->use('getRegistryValue');
    foreach my $test (keys %regval_tests) {

        my $regval = getRegistryValue( %{$regval_tests{$test}} );
        cmp_deeply(
            $regval,
            $regval_tests{$test}->{_expected},
            "$test regval"
        );
    }
}

SKIP: {
    skip 'Windows-specific test', $win32_only_test_count
        unless $OSNAME eq 'MSWin32';

    GLPI::Agent::Tools::Win32->use('runCommand');

    my ($code, $fd) = runCommand(command => "perl -V");
    ok($code eq 0, "perl -V returns 0");

    ok(any { /Summary of my perl5/ } <$fd>, "perl -V output looks good");

    ($code, $fd) = runCommand(
        timeout => 1,
        command => "perl -e\"sleep 10\""
    );
    ok($code eq 293, "timeout=1: timeout catched");
    my $command = "perl -BAD";
    ($code, $fd) = runCommand(
        command => $command,
        no_stderr => 1
    );
    ok(defined(<$fd>), "no_stderr=0: catch STDERR output");

    # From here we need to avoid crashes due to not thread-safe Win32::OLE
    GLPI::Agent::Tools::Win32::start_Win32_OLE_Worker();

    GLPI::Agent::Tools::Win32->use('is64bit');
    ok(defined(is64bit()), "is64bit api call");

    GLPI::Agent::Tools::Win32->use('getLocalCodepage');
    ok(defined(getLocalCodepage()), "getLocalCodepage api call");
    ok(getLocalCodepage() =~ /^cp.+/, "local codepage check");

    # If we crash after that, this means Win32::OLE is not used in a
    # dedicated thread
    my $pid = fork;
    if (defined($pid)) {
        waitpid $pid, 0;
    } else {
        exit(0);
    }
}
