package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.16-gitf79fedc3";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2025-12-17 08:21"
];

1;

