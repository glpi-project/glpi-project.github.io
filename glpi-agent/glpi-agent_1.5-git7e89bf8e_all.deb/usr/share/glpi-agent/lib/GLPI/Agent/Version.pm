package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.5-git7e89bf8e";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2022-07-13 03:20"
];

1;

