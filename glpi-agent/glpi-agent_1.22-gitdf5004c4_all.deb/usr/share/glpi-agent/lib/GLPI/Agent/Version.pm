package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-gitdf5004c4";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-10-28 01:20"
];

1;

