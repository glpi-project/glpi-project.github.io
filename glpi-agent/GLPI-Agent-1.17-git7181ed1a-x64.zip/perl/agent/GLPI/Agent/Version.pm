package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.17-git7181ed1a";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Provided by Teclib Edition",
    "Installer built on Fri Feb 27 03:37:17 2026 UTC",
    "Built with Strawberry Perl 5.42.0",
    "Built on github actions windows image for glpi-project/glpi-agent repository",
];

1;
