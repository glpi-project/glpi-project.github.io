package GLPI::Agent::Task::Deploy::Version;

use strict;
use warnings;

use constant VERSION => "3.5";

1;
