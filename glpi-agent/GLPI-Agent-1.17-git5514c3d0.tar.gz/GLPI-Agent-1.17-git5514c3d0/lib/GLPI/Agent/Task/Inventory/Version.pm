package GLPI::Agent::Task::Inventory::Version;

use strict;
use warnings;

use constant VERSION => "1.23";

1;
