package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git49084d0c";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-10-10 07:04"
];

1;

