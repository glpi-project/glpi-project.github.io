package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.22-git655f524f";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-10-17 01:28"
];

1;

