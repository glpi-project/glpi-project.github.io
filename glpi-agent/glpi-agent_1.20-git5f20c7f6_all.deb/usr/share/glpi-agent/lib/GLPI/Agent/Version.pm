package GLPI::Agent::Version;

use strict;
use warnings;

our $VERSION = "1.20-git5f20c7f6";
our $PROVIDER = "GLPI";
our $COMMENTS = [
    "Built by Debian",
    "Source time: 2026-09-19 05:51"
];

1;

