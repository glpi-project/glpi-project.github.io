// This file is the entry point of webpack.

// TODO Make JS code splitted into modules that can be imported by the "import" directive
