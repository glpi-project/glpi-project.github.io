<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2026 Teclib' and contributors.
 * @copyright 2003-2014 by the INDEPNET Development Team.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

interface NotificationEventInterface
{
    /**
     * Raise a notification event
     *
     * @param string                                    $event              Event
     * @param CommonGLPI                                $item               Notification data
     * @param array                                     $options            Options
     * @param string                                    $label              Label
     * @param array                                     $data               Notification data
     * @param NotificationTarget<covariant CommonGLPI>  $notificationtarget Target
     * @param NotificationTemplate                      $template           Template
     * @param bool                                   $notify_me          Whether to notify current user
     * @param mixed                                     $emitter            If this action is executed by the cron, we can
     *                                                                      supply the id of the user (or the email if this
     *                                                                      is an anonymous user with no account) who
     *                                                                      triggered the event so it can be used instead of
     *                                                                      getLoginUserID
     * @param CommonDBTM|null                           $trigger            Item that raises the notification (in case notification was raised by a child item).
     *
     * @return void
     *
     * @since 11.0.0 Param `$trigger` has been added.
     */
    public static function raise(
        $event,
        CommonGLPI $item,
        array $options,
        $label,
        array $data,
        NotificationTarget $notificationtarget,
        NotificationTemplate $template,
        $notify_me,
        $emitter = null,
        ?CommonDBTM $trigger = null
    );


    /**
     * Get target field name
     *
     * @return string
     */
    public static function getTargetFieldName();

    /**
     * Get (and populate if needed) target field for notification
     *
     * @param array $data Input event data
     *
     * @return string
     */
    public static function getTargetField(&$data);

    /**
     * Whether notifications can be handled by a crontab
     *
     * @return bool
     */
    public static function canCron();

    /**
     * Get admin data
     *
     * @return array
     */
    public static function getAdminData();

    /**
     * Get entity admin data
     *
     * @param int $entity Entity ID
     *
     * @return array
     */
    public static function getEntityAdminsData($entity);

    /**
     * Send notification
     *
     * @param array $data Data to send
     *
     * @return false|int False if something went wrong, number of send notifications otherwise
     */
    public static function send(array $data);
}
