<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2026 Teclib' and contributors.
 * @copyright 2003-2014 by the INDEPNET Development Team.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

require_once(__DIR__ . '/_check_webserver_config.php');

/**
 * Following variables have to be defined before inclusion of this file:
 * @var RuleCollection $rulecollection
 */

use Glpi\Event;

$rule = $rulecollection->getRuleClass();
$rulecollection->checkGlobal(READ);

if (!isset($_GET["id"])) {
    $_GET["id"] = "";
}

if (isset($_POST["update"])) {
    $rulecollection->checkGlobal(UPDATE);
    $rule->check($_POST['id'], UPDATE);
    $rule->update($_POST);

    Event::log(
        $_POST['id'],
        "rules",
        4,
        "setup",
        //TRANS: %s is the user login
        sprintf(__('%s updates an item'), $_SESSION["glpiname"])
    );
    Html::back();
} elseif (isset($_POST["add"])) {
    $rulecollection->checkGlobal(CREATE);

    if (isset($_POST['profiles_id']) && isset($_POST['entities_id']) && isset($_POST['is_recursive'])) {
        $entity = new Entity();
        $entity->executeAddRule($_POST);
    } else {
        $newID = $rule->add($_POST);
        Event::log(
            $newID,
            "rules",
            4,
            "setup",
            sprintf(__('%1$s adds the item %2$s'), $_SESSION["glpiname"], $newID)
        );
        Html::redirect($rule->getFormURLWithID($newID));
    }
} elseif (isset($_POST["purge"])) {
    $rulecollection->checkGlobal(PURGE);
    $rule->check($_POST['id'], PURGE);
    $rulecollection->deleteRuleOrder($_POST["ranking"]);
    $rule->delete($_POST, true);

    Event::log(
        $_POST["id"],
        "rules",
        4,
        "setup",
        //TRANS: %s is the user login
        sprintf(__('%s purges an item'), $_SESSION["glpiname"])
    );
    $rule->redirectToList();
}

$menus = ['admin', $rulecollection->menu_type, $rulecollection->menu_option];
$rule::displayFullPageForItem($_GET["id"], $menus, [
    'formoptions'  => " data-track-changes='true'",
]);
