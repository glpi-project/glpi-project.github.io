<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2026 Teclib' and contributors.
 * @copyright 2003-2014 by the INDEPNET Development Team.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

use Glpi\Application\View\TemplateRenderer;
use Glpi\Plugin\Hooks;

/**
 * NotificationTarget Class
 *
 * @template T of CommonGLPI
 */
class NotificationTarget extends CommonDBChild
{
    /** @var string unused variable */
    public string $prefix                      = '';
    // From CommonDBChild
    public static string $itemtype = Notification::class;
    public static string $items_id             = 'notifications_id';
    public string $table                       = 'glpi_notificationtargets';

    /**
     * @var array<string, string>
     *      key is a formated <Notification::*_TYPE>_<value-of<Notification::TARGETS>>
     *      value is formated <Notification::*_TYPE>_<string(label)>
     */
    public array $notification_targets        = [];

    /**
     * @var array<Notification::*_TYPE, array<int, string>>
     */
    public array $notification_targets_labels = [];

    /**
     * @var array<string, string|array<string>> Data from the objet which can be used by the template
     */
    public array $data                        = [];

    /**
     * @var array<string, string|array<string|array>>
     */
    public array $tag_descriptions = [];

    // From CommonDBTM
    public bool $dohistory                   = true;

    /**
     * @var array<string, array{
     *                      language: string,
     *                      additionnaloption: array,
     *                      username: string,
     *     }> store emails by notification
     */
    public array $target                      = [];

    public int $entity;

    /**
     * @var T|null Object which raises the notification event
     */
    public $obj                         = null;

    /**
     * @var array<CommonGLPI> Object which is associated with the event
     */
    public array $target_object               = [];

    /**
     * @var array<string, string>
     */
    public array $events = [];

    /**
     * @var array{
     *     _old_user?: array{
     *          type?: CommonITILActor::ASSIGN|CommonITILActor::REQUESTER|CommonITILActor::OBSERVER,
     *          use_notification?: bool,
     *          users_id?: int,
     *          alternative_email?: string,
     *     },
     *     sendprivate?: bool}
     */
    public array $options = [];

    public string $raiseevent  = '';

    /**
     * Recipient related to called "add_recipient_to_target" hook.
     * Variable contains `itemtype` and `items_id` keys and is set only during hook execution.
     * @var array{itemtype?: class-string<CommonDBTM>, items_id?: int}
     */
    public array $recipient_data              = [];

    private bool $allow_response        = true;

    /** @var Notification_NotificationTemplate::MODE_*|null */
    private ?string $mode               = null;

    private ?string $event                      = null;

    /** @var string */
    public const TAG_LANGUAGE               = 'lang';

    /** @var string */
    public const TAG_VALUE                  = 'tag';
    public const TAG_FOR_ALL_EVENTS         = 0;

    public const ANONYMOUS_USER             = 0;
    public const GLPI_USER                  = 1;
    public const EXTERNAL_USER              = 2;

    /**
     * @param int|null        $entity
     * @param string          $event
     * @param CommonGLPI|null $object
     * @param array{
     *      _old_user?: array{
     *           type?: CommonITILActor::ASSIGN|CommonITILActor::REQUESTER|CommonITILActor::OBSERVER,
     *           use_notification?: bool,
     *           users_id?: int,
     *           alternative_email?: string,
     *      },
     *      sendprivate?: bool} $options
     **/
    public function __construct($entity = null, $event = '', $object = null, $options = [])
    {
        if ($entity === null) {
            $this->entity = ($_SESSION['glpiactive_entity'] ?? 0);
        } else {
            $this->entity = $entity;
        }

        if ($object) {
            $this->obj = $object;
            $this->getObjectItem($event);
        }

        $this->raiseevent = $event;
        $this->options    = $options;

        $this->addNotificationTargets($this->entity);

        $this->addAdditionalTargets($event);

        // add new target by plugin
        $this->data = [];
        Plugin::doHook(Hooks::ITEM_ADD_TARGETS, $this);
        asort($this->notification_targets);

        $this->registerGlobalTags();
    }

    #[Override]
    public static function getTable($classname = null): string
    {
        return parent::getTable(self::class);
    }

    #[Override]
    public static function getIcon()
    {
        return Notification::getIcon();
    }

    /**
     * Retrieve an item from the database for a specific target
     *
     * @param int                      $notifications_id
     * @param class-string<CommonDBTM> $type             type of the target to retrive
     * @param int                      $ID               ID of the target to retrieve
     *
     * @return bool
     *
     * @since 0.85
     */
    public function getFromDBForTarget($notifications_id, $type, $ID)
    {

        if (
            $this->getFromDBByCrit([
                static::getTable() . '.notifications_id'   => $notifications_id,
                static::getTable() . '.items_id'           => $ID,
                static::getTable() . '.type'               => $type,
            ])
        ) {
            return true;
        }
        return false;
    }

    /**
     * Validate send before doing it (can be overloaded : exemple for private tasks or followups)
     *
     * @param string          $event     notification event
     * @param array           $infos     destination of the notification
     * @param bool            $notify_me notify me on my action ?
     *                                   ($infos contains users_id to check if the target is me)
     * @param int|string|null $emitter   if this action is executed by the cron, we can
     *                                   supply the id of the user (or the email if this
     *                                   is an anonymous user with no account) who
     *                                   triggered the event so it can be used instead of
     *                                   getLoginUserID
     *
     * @return bool
     **/
    public function validateSendTo($event, array $infos, $notify_me = false, $emitter = null)
    {
        $users_id = Session::getLoginUserID(false);

        // Override session ID with emitter ID if supplied
        if (is_int($emitter)) {
            // We have an ID, we can use it directly
            $users_id = $emitter;
        } elseif (is_string($emitter)) {
            // We have an email, we need to check that the users_id is -1 which
            // is the value used for anonymous user and compare the emails
            if (
                isset($infos['users_id']) && $infos['users_id'] == -1
                && isset($infos['email']) && $infos['email'] == $emitter
            ) {
                $users_id = -1;
            }
        }

        if (!$notify_me) {
            if (
                isset($infos['users_id'])
                // Check login user and not event launch by crontask
                && ($infos['users_id'] === $users_id)
            ) {
                return false;
            }
        }

        //do not notify if user explicitly refused it
        $user = new User();
        if (
            $this->canNotificationBeDisabled($event)
            && isset($infos['users_id'])
            && $user->getFromDB($infos['users_id'])
            && !$user->isUserNotificationEnable()
        ) {
            return false;
        }
        return true;
    }

    /**
     * Check if notification (for a specific event) can be disabled
     *
     * @return bool
     **/
    protected function canNotificationBeDisabled(string $event): bool
    {
        return true;
    }

    /**
     * @param string $event
     * @return string
     */
    public function getSubjectPrefix($event = '')
    {
        $perso_tag = trim(Entity::getUsedConfig(
            'notification_subject_tag',
            $this->getEntity(),
            '',
            ''
        ));
        if (empty($perso_tag)) {
            $perso_tag = "GLPI";
        }
        return "[$perso_tag] ";
    }

    /**
     * Get header to add to content
     *
     * @return string
     **/
    public function getContentHeader()
    {
        return '';
    }

    /**
     * Get footer to add to content
     *
     * @return string
     **/
    public function getContentFooter()
    {
        return '';
    }

    /**
     * Get message ID for current notification.
     *
     * @since 0.84
     *
     * @return string
     */
    public function getMessageID()
    {
        return self::getMessageIdForEvent(
            $this->obj instanceof CommonDBTM ? $this->obj::class : null,
            $this->obj instanceof CommonDBTM ? $this->obj->getID() : null,
            $this->raiseevent
        );
    }

    /**
     * Get message ID for given item/event.
     *
     * @param string|null $itemtype
     * @param int|null $items_id
     * @param string|null $event
     *
     * @return string
     */
    final public static function getMessageIdForEvent(?string $itemtype, ?int $items_id, ?string $event): string
    {
        if (empty($event)) {
            $event = 'none';
        }
        $is_item_related = !empty($itemtype) && is_a($itemtype, CommonDBTM::class, true);

        $message_id  = 'GLPI';
        $message_id .= sprintf('_%s', Config::getUuid('notification'));

        $reference_event = null;
        if ($is_item_related) {
            $message_id .= sprintf(
                '-%s-%d',
                str_replace('\\', '-', $itemtype), // RFC 2822 does not allow backslashes (namespaced classes)
                $items_id
            );
            $reference_event = $itemtype::getMessageReferenceEvent($event);
        }

        $message_id .= sprintf('/%s', $event);

        if ($reference_event === null || $event !== $reference_event) {
            // Add random, unless event is the reference event for the related item.
            // eg. no random will be added for `new` event of a ticket, but a random will be added for `add_followup` events.
            $message_id .= sprintf('.%d.%d', time(), random_int(0, mt_getrandmax()));
        }

        $message_id .= sprintf('@%s', php_uname('n'));

        return $message_id;
    }


    #[Override]
    public static function getTypeName($nb = 0)
    {
        return _n('Recipient', 'Recipients', $nb);
    }

    #[Override]
    protected function computeFriendlyName()
    {

        return $this->notification_targets_labels[$this->fields["type"]]
                                              [$this->fields["items_id"]] ?? '';
    }

    /**
     * Get a notificationtarget class by giving the object which raises the event
     *
     * @template Item of CommonGLPI
     *
     * @param Item        $item    Object which raises the event
     * @param string|null $event
     * @param array       $options
     *
     * @return NotificationTarget<Item>|false
     */
    public static function getInstance($item, $event = '', $options = [])
    {
        $name = self::getInstanceClass($item::class);

        $entity = 0;
        if (is_a($name, NotificationTarget::class, true)) {
            //Entity ID exists in the options array
            if (isset($options['entities_id'])) {
                $entity = $options['entities_id'];
            } elseif (method_exists($item, 'getEntityID') && $item->getEntityID() >= 0) {
                //Item which raises the event contains an entityID
                $entity = $item->getEntityID();
            }

            return new $name($entity, $event, $item, $options);
        }
        return false;
    }

    /**
     * Get the expected notification target class name for a given itemtype
     *
     * @template Item of CommonGLPI
     *
     * @param class-string<Item> $itemtype
     * @return class-string<NotificationTarget<Item>>
     */
    public static function getInstanceClass(string $itemtype): string
    {
        if (str_contains($itemtype, "\\")) {
            // namespace case
            $ns_parts = explode("\\", $itemtype);
            $classname = array_pop($ns_parts);
            $name = implode("\\", $ns_parts) . "\\NotificationTarget$classname";
        } elseif ($plug = isPluginItemType($itemtype)) {
            // plugins case
            $name = 'Plugin' . $plug['plugin'] . 'NotificationTarget' . $plug['class'];
        } else {
            // simple class (without namespace)
            $name = "NotificationTarget$itemtype";
        }

        return $name;
    }

    /**
     * Get a notificationtarget class by giving an itemtype
     *
     * @template Item of CommonGLPI
     *
     * @param class-string<Item> $itemtype the itemtype of the object which raises the event
     * @param string|null        $event    Event which will be used
     * @param array              $options
     *
     * @return NotificationTarget<Item>|false
     */
    public static function getInstanceByType($itemtype, $event = '', $options = [])
    {
        if (
            ($itemtype)
            && ($item = getItemForItemtype($itemtype))
        ) {
            return self::getInstance($item, $event, $options);
        }
        return false;
    }

    public function showForNotification(Notification $notification): bool
    {
        if (!Notification::canView()) {
            return false;
        }

        if ($notification->fields['itemtype'] != '') {
            $notifications_id = $notification->fields['id'];
            $canedit = $notification->can($notifications_id, UPDATE);

            $values = [];
            $allowed_exclusion_types = [
                Notification::PROFILE_TYPE,
                Notification::GROUP_TYPE,
            ];
            $all_exclusion_targets = [];
            foreach (array_keys($this->notification_targets) as $key) {
                [$type, $id] = explode('_', $key);
                $label = $this->notification_targets_labels[$type][$id];
                if (in_array((int) $type, $allowed_exclusion_types, true)) {
                    $all_exclusion_targets[$key] = $label;
                }
                $values[$key] = $label;
            }

            $targets = getAllDataFromTable(
                self::getTable(),
                [
                    'notifications_id' => $notifications_id,
                ]
            );
            $actives = [];
            $exclusions = [];
            if (count($targets)) {
                foreach ($targets as $data) {
                    $target_key = $data['type'] . '_' . $data['items_id'];
                    if ($data['is_exclusion']) {
                        $exclusions[$target_key] = $target_key;
                    } else {
                        $actives[$target_key] = $target_key;
                    }
                }
            }
            TemplateRenderer::getInstance()->display('pages/setup/notification/recipients.html.twig', [
                'item' => $this,
                'notification' => $notification,
                'all_targets' => $values,
                'all_exclusion_targets' => $all_exclusion_targets,
                'active_targets' => $actives,
                'excluded_targets' => $exclusions,
                'params' => [
                    'canedit' => $canedit,
                ],
            ]);
        }

        return true;
    }

    /**
     * @param array{
     *     itemtype: class-string<CommonDBTM>,
     *     notifications_id?: int,
     *     _targets?: array<string>,
     *     _exclusions?: array<string>
     *     } $input
     *
     * This method has no effect if $input parameter has no 'notifications_id' key
     *
     * @return void
     **/
    public static function updateTargets($input)
    {
        $target = self::getInstanceByType($input['itemtype']);

        if (!isset($input['notifications_id'])) {
            return;
        }

        $targets = getAllDataFromTable(
            self::getTable(),
            [
                'notifications_id' => $input['notifications_id'],
            ]
        );
        $actives = [];
        if (count($targets)) {
            foreach ($targets as $data) {
                $actives[$data['type'] . '_' . $data['items_id']] = $data['type'] . '_' . $data['items_id'];
            }
        }
        // Be sure to have items once
        $actives = array_unique($actives);
        if (isset($input['_targets']) && count($input['_targets'])) {
            // Be sure to have items once
            $input['_targets'] = array_unique($input['_targets']);
            foreach ($input['_targets'] as $val) {
                // Add if not set
                if (!isset($actives[$val])) {
                    [$type, $items_id]   = explode("_", $val);
                    $tmp                     = [];
                    $tmp['items_id']         = $items_id;
                    $tmp['type']             = $type;
                    $tmp['notifications_id'] = $input['notifications_id'];
                    $target->add($tmp);
                }
                unset($actives[$val]);
            }
        }

        if (isset($input['_exclusions']) && is_array($input['_exclusions']) && count($input['_exclusions'])) {
            $input['_exclusions'] = array_unique($input['_exclusions']);
            // Remove exclusions already set in _targets
            $input['_exclusions'] = array_diff($input['_exclusions'], $input['_targets'] ?? []);
            foreach ($input['_exclusions'] as $val) {
                // Add if not set
                if (!isset($actives[$val])) {
                    [$type, $items_id]   = explode("_", $val);
                    $tmp                     = [];
                    $tmp['items_id']         = $items_id;
                    $tmp['type']             = $type;
                    $tmp['notifications_id'] = $input['notifications_id'];
                    $tmp['is_exclusion']     = 1;
                    $target->add($tmp);
                }
                unset($actives[$val]);
            }
        }

        // Drop others
        if (count($actives)) {
            foreach ($actives as $val) {
                [$type, $items_id] = explode("_", $val);
                if ($target->getFromDBForTarget($input['notifications_id'], $type, (int) $items_id)) {
                    $target->delete(['id' => $target->getID()]);
                }
            }
        }
    }

    /**
     * @return void
     */
    public function addAdditionnalInfosForTarget() {}

    /**
     * @return array
     **/
    public function addAdditionnalUserInfo(array $data)
    {
        return [];
    }

    /**
     * Add new recipient with lang to current recipients array
     *
     * @param $data array{
     *              language?: string,
     *              name?: string,
     *              users_id?: int,
     *              usertype?: int,
     *              }
     *
     * @return void
     **/
    public function addToRecipientsList(array $data)
    {
        global $CFG_GLPI;
        $new_lang = '';

        // Default USER TYPE is ANONYMOUS
        $notificationoption = ['usertype' => self::ANONYMOUS_USER];

        if (isset($data['language'])) {
            $new_lang = trim($data['language']);
        }
        $username = '';
        if (isset($data['name']) && !empty($data['name'])) {
            $username = $data['name'];
        }
        if (isset($data['users_id']) && ($data['users_id'] > 0)) {
            $user = new User();
            if (
                !$user->getFromDB($data['users_id'])
                || ($user->isDeleted())
                || (!$user->isActive())
                || (!is_null($user->fields['begin_date'])
                  && ($user->fields['begin_date'] > $_SESSION["glpi_currenttime"]))
                || (!is_null($user->fields['end_date'])
                  && ($user->fields['end_date'] < $_SESSION["glpi_currenttime"]))
            ) {
                // unknown, deleted or disabled user
                return;
            }
            $filt = getEntitiesRestrictCriteria(
                'glpi_profiles_users',
                '',
                $this->getEntity(),
                true
            );

            // If one of the item is recursive, then we should also check the child entities
            if ($this->isTargetItemRecursive()) {
                $filt = [
                    'OR' => [
                        $filt,
                        ['entities_id' => getSonsOf(Entity::getTable(), $this->getEntity())],
                    ],
                ];
            }

            $prof = Profile_User::getUserProfiles($data['users_id'], $filt);
            if (!count($prof)) {
                // No right on the entity of the object
                return;
            }
            if (empty($username)) {
                $username = formatUserName(
                    0,
                    $user->fields['name'],
                    $user->fields['realname'],
                    $user->fields['firstname'],
                    force_config: true
                );
            }
            // It is a GLPI user :
            $notificationoption['usertype'] = self::GLPI_USER;
            if (
                $user->fields['authtype'] == Auth::LDAP
                || Auth::isAlternateAuth($user->fields['authtype'])
                || (($user->fields['authtype'] == Auth::NOT_YET_AUTHENTIFIED)
                 && Auth::isAlternateAuth(Auth::checkAlternateAuthSystems()))
            ) {
                $notificationoption['usertype'] = self::EXTERNAL_USER;
            }

            // retrieve timezone of the user if exists
            if (!empty($user->fields['timezone']) && 'null' !== strtolower($user->fields['timezone'])) {
                $notificationoption['timezone'] = $user->fields['timezone'];
            }

            // retrieve date_format preference of the user, fall back to global config if not set
            $notificationoption['date_format'] = (int) ($user->fields['date_format'] ?? $CFG_GLPI['date_format'] ?? 0);
        }

        // Pass user type as argument ? forced for specific cases
        if (isset($data['usertype'])) {
            $notificationoption['usertype'] = $data['usertype'];
        }

        $notificationoption = array_merge(
            $this->addAdditionnalUserInfo($data),
            $notificationoption
        );

        $param = [
            'language'           => (empty($new_lang) ? $CFG_GLPI["language"] : $new_lang),
            'additionnaloption'  => $notificationoption,
            'username'           => $username,
        ];
        if (isset($data['users_id']) && $data['users_id']) {
            $param['users_id'] = $data['users_id'];
        }

        $eventclass = $this->event;
        $target_field = $eventclass::getTargetField($data, $param);
        if ($data[$target_field] !== null) {
            $param[$target_field] = $data[$target_field];
            $this->target[$data[$target_field]] = $param;
        }

        if (isset($data['users_id']) && $data['users_id']) {
            $this->recipient_data = [
                'itemtype' => User::class,
                'items_id' => $data['users_id'],
            ];
            Plugin::doHook(Hooks::ADD_RECIPIENT_TO_TARGET, $this);
            $this->recipient_data = [];
        }
    }

    /**
     * @return self::EXTERNAL_USER|self::GLPI_USER
     *
     * @since 0.84
     */
    public function getDefaultUserType()
    {
        return Auth::isAlternateAuth(Auth::checkAlternateAuthSystems())
            ? self::EXTERNAL_USER
            : self::GLPI_USER;
    }

    /**
     * @param self::EXTERNAL_USER|self::GLPI_USER|self::ANONYMOUS_USER $usertype
     * @param string                                                   $redirect
     *
     * @return string
     *
     * @since 0.84
     */
    public function formatURL($usertype, $redirect, ?string $anchor = null)
    {
        if (urldecode($redirect) === $redirect) {
            // `redirect` parameter value have to be url-encoded.
            // Prior to GLPI 10.0.3, method caller was responsible for this encoding,
            // so we have to ensure that param is not already encoded before encoding it,
            // to prevent BC breaks.
            $redirect = rawurlencode($redirect);
        }

        if (!empty($anchor)) {
            // anchor have to be url-encoded to correctly pass '#' character as '%23'
            $anchor = rawurlencode('#' . $anchor);
        }

        $base_url = $this->getUrlBase();

        switch ($usertype) {
            case self::EXTERNAL_USER:
            case self::GLPI_USER:
                return "$base_url/index.php?redirect={$redirect}{$anchor}";

                // case self::ANONYMOUS_USER:
            default:
                // No URL
                return '';
        }
    }


    /**
     * Add GLPI's global administrator email
     *
     * @return void
     */
    final public function addAdmin()
    {
        $eventclass = $this->event;
        $admin_data = $eventclass::getAdminData();

        if ($admin_data) {
            if (!isset($admin_data['users_id']) && !isset($admin_data['usertype'])) {
                $admin_data['usertype'] = $this->getDefaultUserType();
            }
            $this->addToRecipientsList($admin_data);
        }
    }


    /**
     * Add item's author
     *
     * @since 9.2
     *
     * @return void
     */
    public function addItemAuthor()
    {
        if (!$this->obj instanceof CommonDBTM) {
            return;
        }

        $user = new User();
        if (
            $this->obj->isField('users_id')
            && $user->getFromDB($this->obj->fields['users_id'])
        ) {
            $this->addToRecipientsList([
                'language' => $user->fields['language'],
                'users_id' => $user->getID(),
            ]);
        }
    }

    /**
     * Add item's group
     *
     * @since 9.2
     *
     * @return void
     */
    final public function addItemGroup()
    {
        if ($this->target_object !== []) {
            foreach ($this->target_object as $target) {
                if (!$target instanceof CommonDBTM) {
                    continue;
                }

                if ($target->fields['groups_id'] > 0) {
                    $this->addForGroup(0, $target->fields['groups_id']);
                }
            }
        }
    }

    /**
     * Add item's group supervisor
     *
     * @since 9.2
     *
     * @return void
     */
    final public function addItemGroupSupervisor()
    {
        if ($this->target_object !== []) {
            foreach ($this->target_object as $target) {
                if (!$target instanceof CommonDBTM) {
                    continue;
                }

                if ($target->fields['groups_id'] > 0) {
                    $this->addForGroup(1, $target->fields['groups_id']);
                }
            }
        }
    }

    /**
     * Add item's group users exepted supervisor
     *
     * @since 9.2
     *
     * @return void
     */
    final public function addItemGroupWithoutSupervisor()
    {
        if ($this->target_object !== []) {
            foreach ($this->target_object as $target) {
                if (!$target instanceof CommonDBTM) {
                    continue;
                }

                if ($target->fields['groups_id'] > 0) {
                    $this->addForGroup(2, $target->fields['groups_id']);
                }
            }
        }
    }

    /**
     * Add entity admin
     *
     * @return void
     */
    final public function addEntityAdmin()
    {
        $eventclass = $this->event;
        $admins_data = $eventclass::getEntityAdminsData($this->entity);

        if ($admins_data) {
            foreach ($admins_data as $admin_data) {
                if (!isset($admin_data['users_id']) && !isset($admin_data['usertype'])) {
                    $admin_data['usertype'] = $this->getDefaultUserType();
                }
                $this->addToRecipientsList($admin_data);
            }
        }
    }

    /**
     * Add users of a group to targets
     *
     * @param int $manager  0 all users, 1 only supervisors, 2 all users without supervisors
     * @param int $group_id id of the group
     *
     * @since 9.2
     *
     * @return void
     **/
    final public function addForGroup($manager, $group_id)
    {
        global $DB;

        // members/managers of the group allowed on object entity
        // filter group with 'is_assign' (attribute can be unset after notification)
        $criteria = $this->getDistinctUserCriteria() + $this->getProfileJoinCriteria();
        $criteria['FROM'] = Group_User::getTable();
        $criteria['INNER JOIN'] = array_merge(
            [
                User::getTable() => [
                    'ON' => [
                        Group_User::getTable()  => 'users_id',
                        User::getTable()        => 'id',
                    ],
                ],
                Group::getTable() => [
                    'ON' => [
                        Group_User::getTable()  => 'groups_id',
                        Group::getTable()       => 'id',
                    ],
                ],
            ],
            $criteria['INNER JOIN'] ?? []
        );
        $criteria['WHERE'] = array_merge(
            $criteria['WHERE'] ?? [],
            [
                Group_User::getTable() . '.groups_id'  => $group_id,
                Group::getTable() . '.is_notify'       => 1,
            ]
        );

        if ($manager == 1) {
            $criteria['WHERE']['glpi_groups_users.is_manager'] = 1;
        } elseif ($manager == 2) {
            $criteria['WHERE']['glpi_groups_users.is_manager'] = 0;
        }

        $iterator = $DB->request($criteria);
        foreach ($iterator as $data) {
            $this->addToRecipientsList($data);
        }

        if ($manager != 1) {
            // Do not consider it as a group notification if it only targets supervisor
            $this->recipient_data = [
                'itemtype' => Group::class,
                'items_id' => $group_id,
            ];
            Plugin::doHook(Hooks::ADD_RECIPIENT_TO_TARGET, $this);
            $this->recipient_data = [];
        }
    }


    /**
     * Get request criteria to select uniques users
     *
     * @since 9.4
     *
     * @return array
     */
    final public function getDistinctUserCriteria()
    {
        return [
            'FIELDS'          => [
                User::getTable() . '.id AS users_id',
                User::getTable() . '.language AS language',
            ],
            'DISTINCT'        => true,
        ];
    }


    /**
     * Return main notification events for the object type
     * Internal use only => should use getAllEvents
     *
     * @return array<string, string> event name => event label
     **/
    public function getEvents()
    {
        return [];
    }

    /**
     * Return list of notification events for which the notifications should be sent immediately.
     *
     * @return array
     */
    public function getEventsToSendImmediately(): array
    {
        return [];
    }

    /**
     * Indicates whether the notification should be sent immediately.
     *
     * @param class-string<CommonDBTM> $itemtype
     */
    public static function shouldNotificationBeSentImmediately(string $itemtype, string $event): bool
    {
        $target_class = NotificationTarget::getInstanceClass($itemtype);

        if (!is_a($target_class, NotificationTarget::class, true)) {
            return false;
        }

        $target = new $target_class();

        return in_array($event, $target->getEventsToSendImmediately(), true);
    }

    /**
     * Return whether the notification content corresponding to the given event can be disclosed.
     *
     * @return bool
     */
    public function canNotificationContentBeDisclosed(string $event): bool
    {
        return true;
    }

    /**
     * Return all (GLPI + plugins) notification events for the object type
     *
     * @return array<string, string> [event => event label, ...]
     **/
    public function getAllEvents()
    {
        $this->events = $this->getEvents();
        //If plugin adds new events for an already defined type
        Plugin::doHook(Hooks::ITEM_GET_EVENTS, $this);

        return $this->events;
    }

    /**
     * @param ?int $target
     * @param string                      $label  Recipient label
     * @param Notification::*_TYPE        $type   Recipient type
     *
     * @return void
     */
    public function addTarget($target = null, $label = '', $type = Notification::USER_TYPE)
    {
        $key                                               = ((string) $type) . '_' . $target;
        // Value used for sort
        $this->notification_targets[$key]                  = ((string) $type) . '_' . $label;
        // Displayed value
        $this->notification_targets_labels[$type][$target] = $label;
    }

    /**
     * @return void
     */
    public function addProfilesToTargets()
    {
        global $DB;

        $profiles = $DB->request(['FROM' => Profile::getTable()]);
        foreach ($profiles as $data) {
            $this->addTarget(
                $data["id"],
                sprintf(__('%1$s: %2$s'), Profile::getTypeName(1), $data["name"]),
                Notification::PROFILE_TYPE
            );
        }
    }


    /**
     * @param int|int[]|'' $entity (could maybe be narrowed, using getEntitiesRestrictCriteria() signature)
     *
     * @return void
     */
    final public function addGroupsToTargets($entity)
    {
        global $DB;

        // Filter groups which can be notified and have members (as notifications are sent to members)
        $iterator = $DB->request([
            'SELECT' => ['id', 'name'],
            'FROM'   => Group::getTable(),
            'WHERE'  => [
                'is_usergroup' => 1,
                'is_notify'    => 1,
            ] + getEntitiesRestrictCriteria('glpi_groups', 'entities_id', $entity, true),
            'ORDER'  => 'name',
        ]);

        foreach ($iterator as $data) {
            //Add group
            $this->addTarget(
                $data["id"],
                sprintf(__('%1$s: %2$s'), Group::getTypeName(1), $data["name"]),
                Notification::GROUP_TYPE
            );
            //Add group supervisor
            $this->addTarget(
                $data["id"],
                sprintf(
                    __('%1$s: %2$s'),
                    __('Manager of group'),
                    $data["name"]
                ),
                Notification::SUPERVISOR_GROUP_TYPE
            );
            //Add group without supervisor
            $this->addTarget(
                $data["id"],
                sprintf(
                    __('%1$s: %2$s'),
                    __("Group except manager users"),
                    $data["name"]
                ),
                Notification::GROUP_WITHOUT_SUPERVISOR_TYPE
            );
        }
    }

    /**
     * Add all targets for this notification
     *
     * Can be updated by implementing the addAdditionnalTargets() method
     * Can be overriden (like dbconnection)
     *
     * @param int $entity the entity on which the event is raised
     *
     * @return void
     **/
    public function addNotificationTargets($entity)
    {
        if (Session::haveRight("config", UPDATE)) {
            $this->addTarget(Notification::GLOBAL_ADMINISTRATOR, __('Administrator'));
        }
        $this->addTarget(Notification::ENTITY_ADMINISTRATOR, __('Entity administrator'));

        $this->addProfilesToTargets();
        $this->addGroupsToTargets($entity);
    }

    /**
     * Allows to add more notification targets
     * Can be overridden in some case (for example Ticket)
     *
     * @param string $event specif event to get additional targets (default '')
     *
     * @return void
     */
    public function addAdditionalTargets($event = '') {}

    /**
     * Add targets by a method not defined in NotificationTarget (specific to an itemtype)
     *
     * @param array $data    Data
     * @param array $options Options
     *
     * @return void
     **/
    public function addSpecificTargets($data, $options) {}

    /**
     * Push $this->obj in $this->target_object array
     *
     * Parameter $event is ignored
     *
     * @param string $event
     *
     * @return void
     */
    public function getObjectItem($event = '')
    {
        $this->target_object[] = $this->obj;
    }

    /**
     * Add user to the notified users list
     *
     * @param string  $field            look for user looking for this field in the object
     *                                  which raises the event
     * @param bool $search_in_object search is done in the object ? if not  in target object
     *                                  (false by default)
     *
     * @return void
     **/
    final public function addUserByField($field, $search_in_object = false)
    {
        global $DB;

        $id = [];
        if (!$search_in_object) {
            if (!$this->obj instanceof CommonDBTM) {
                return;
            }

            $id[] = $this->obj->fields[$field];
        } elseif ($this->target_object !== []) {
            foreach ($this->target_object as $target) {
                if (!$target instanceof CommonDBTM) {
                    continue;
                }

                $id[] = $target->fields[$field];
            }
        }

        if ($id !== []) {
            //Look for the user by his id
            $criteria = $this->getDistinctUserCriteria() + $this->getProfileJoinCriteria();
            $criteria['FROM'] = User::getTable();
            $criteria['WHERE'][User::getTable() . '.id'] = $id;
            $iterator = $DB->request($criteria);

            foreach ($iterator as $data) {
                //Add the user email and language in the notified users list
                $this->addToRecipientsList($data);
            }
        }
    }

    /**
     * Add technician in charge of the item
     *
     * @return void
     **/
    final public function addItemTechnicianInCharge()
    {
        $this->addUserByField('users_id_tech', true);
    }

    /**
     * Add group of technicians in charge of the item
     *
     * @return void
     */
    final public function addItemGroupTechInCharge()
    {
        if ($this->target_object !== []) {
            foreach ($this->target_object as $val) {
                if (!$this->obj instanceof CommonDBTM) {
                    continue;
                }

                if (isset($val->fields['groups_id_tech']) && $val->fields['groups_id_tech'] > 0) {
                    $this->addForGroup(0, $val->fields['groups_id_tech']);
                }
            }
        }
    }

    /**
     * Add owner of the material
     *
     * @return void
     **/
    final public function addItemOwner()
    {
        $this->addUserByField('users_id', true);
    }

    /**
     * Add users from a profile
     *
     * @param int $profiles_id the profile ID
     *
     * @return void
     */
    final public function addForProfile($profiles_id)
    {
        global $DB;

        $criteria = $this->getDistinctUserCriteria() + $this->getProfileJoinCriteria();
        $criteria['FIELDS'][] = Profile_User::getTable() . '.entities_id AS entity';
        $criteria['FROM'] = User::getTable();
        $criteria['WHERE'][Profile_User::getTable() . '.profiles_id'] = $profiles_id;

        $iterator = $DB->request($criteria);
        foreach ($iterator as $data) {
            $this->addToRecipientsList($data);
        }

        $this->recipient_data = [
            'itemtype' => Profile::class,
            'items_id' => $profiles_id,
        ];
        Plugin::doHook(Hooks::ADD_RECIPIENT_TO_TARGET, $this);
        $this->recipient_data = [];
    }


    /**
     * Get email to use as a sender for the notifications
     *
     * @return array [email => sender address, name => sender name]
     */
    public function getSender(): array
    {
        // Compute config values
        return Config::getEmailSender(
            $this->getEntity(),
            !$this->allowResponse()
        );
    }


    /**
     * Get the reply to address
     *
     * @return array [email => replyto address, name => replyto name]
     **/
    public function getReplyTo(): array
    {
        if (!$this->allowResponse()) {
            return Config::getNoReplyEmailSender($this->getEntity());
        }
        return Config::getReplyToEmailSender($this->getEntity());
    }


    /**
     * Get the url base for the entity
     *
     * @return string
     */
    public function getUrlBase()
    {
        global $CFG_GLPI;

        $url_base = trim(Entity::getUsedConfig('url_base', $this->getEntity(), '', ''));
        if ($url_base !== '') {
            return $url_base;
        }

        return $CFG_GLPI['url_base'];
    }

    /**
     * Add addresses according to type of notification
     *
     * @param array $data    Data
     * @param array $options Option
     *
     * @return void
     **/
    final public function addForTarget($data, $options = [])
    {

        //Look for all targets whose type is Notification::USER_TYPE
        switch ($data['type']) {
            //Notifications for one people
            case Notification::USER_TYPE:
                switch ($data['items_id']) {
                    //Send to glpi's global admin (as defined in the mailing configuration)
                    case Notification::GLOBAL_ADMINISTRATOR:
                        if ($this->isMailMode()) {
                            $this->addAdmin();
                        }
                        break;

                        //Send to the entity's admninistrator
                    case Notification::ENTITY_ADMINISTRATOR:
                        if ($this->isMailMode()) {
                            $this->addEntityAdmin();
                        }
                        break;

                        //Technician in charge of the ticket
                    case Notification::ITEM_TECH_IN_CHARGE:
                        $this->addItemTechnicianInCharge();
                        break;

                        //Group of technician in charge of the ticket
                    case Notification::ITEM_TECH_GROUP_IN_CHARGE:
                        $this->addItemGroupTechInCharge();
                        break;

                        //User who's owner of the material
                    case Notification::ITEM_USER:
                        $this->addItemOwner();
                        break;

                        //Send to the author of the ticket
                    case Notification::AUTHOR:
                        $this->addItemAuthor();
                        break;

                    default:
                        //Maybe a target specific to a type
                        $this->addSpecificTargets($data, $options);
                }
                break;

                //Send to all the users of a group
            case Notification::GROUP_TYPE:
                $this->addForGroup(0, $data['items_id']);
                break;

                //Send to all the users of a group
            case Notification::SUPERVISOR_GROUP_TYPE:
                $this->addForGroup(1, $data['items_id']);
                break;

                //Send to all the users of a profile
            case Notification::PROFILE_TYPE:
                $this->addForProfile($data['items_id']);
                break;

            default:
                //Maybe a target specific to a type
                $this->addSpecificTargets($data, $options);
        }
        // action for target from plugin
        $this->data = $data;
        Plugin::doHook(Hooks::ITEM_ACTION_TARGETS, $this);
    }


    /**
     * Add data needed for template processing
     *
     * Provides minimum information for alerts
     * Can be overridden by each NotificationTartget class if needed
     *
     * @param string               $event
     * @param array<string, mixed> $options
     * @return void
     **/
    public function addDataForTemplate($event, $options = []) {}

    /**
     * @return array
     */
    final public function getTargets()
    {
        return $this->removeExcludedTargets($this->target);
    }

    private function removeExcludedTargets(array $target_list): array
    {
        global $DB;

        if ($target_list === []) {
            return $target_list;
        }
        $exclusions = iterator_to_array($DB->request([
            'SELECT' => ['type', 'items_id'],
            'FROM'   => self::getTable(),
            'WHERE'  => [
                'is_exclusion'     => 1,
                'notifications_id' => $this->data['notifications_id'],
            ],
        ]));
        if ($exclusions === []) {
            // No exclusion, no need to filter
            return $target_list;
        }
        $user_ids = [];
        foreach ($target_list as $target) {
            if (isset($target['users_id'])) {
                $user_ids[] = $target['users_id'];
            }
        }
        if ($user_ids === []) {
            // Cannot filter targets without a user id
            return $target_list;
        }

        // Separate exclusions by type to avoid confusion between profiles and groups
        $profile_exclusions = [];
        $group_exclusions   = [];
        foreach ($exclusions as $ex) {
            if (!isset($ex['type'], $ex['items_id'])) {
                continue;
            }
            if ((int) $ex['type'] === Notification::PROFILE_TYPE) {
                $profile_exclusions[] = (int) $ex['items_id'];
            } elseif ((int) $ex['type'] === Notification::GROUP_TYPE) {
                $group_exclusions[] = (int) $ex['items_id'];
            }
        }

        $excluded_user_ids = [];

        // Recover excluded users via profiles
        if ($profile_exclusions !== []) {
            $it = $DB->request([
                'SELECT' => [Profile_User::getTableField('users_id')],
                'FROM'   => Profile_User::getTable(),
                'WHERE'  => [
                    Profile_User::getTableField('profiles_id') => $profile_exclusions,
                    Profile_User::getTableField('users_id')    => $user_ids,
                ],
            ]);
            foreach ($it as $data) {
                $excluded_user_ids[] = (int) $data['users_id'];
            }
        }

        // Recover excluded users via groups
        if ($group_exclusions !== []) {
            $it = $DB->request([
                'SELECT' => [Group_User::getTableField('users_id')],
                'FROM'   => Group_User::getTable(),
                'WHERE'  => [
                    Group_User::getTableField('groups_id') => $group_exclusions,
                    Group_User::getTableField('users_id')  => $user_ids,
                ],
            ]);
            foreach ($it as $data) {
                $excluded_user_ids[] = (int) $data['users_id'];
            }
        }

        $excluded_user_ids = array_unique($excluded_user_ids);

        if ($excluded_user_ids === []) {
            return $target_list;
        }

        foreach ($target_list as $key => $target) {
            if (isset($target['users_id']) && in_array($target['users_id'], $excluded_user_ids, true)) {
                unset($target_list[$key]);
            }
        }

        return $target_list;
    }

    /**
     * @return int
     */
    public function getEntity()
    {
        return $this->entity;
    }

    /**
     * @return void
     */
    public function clearAddressesList()
    {
        $this->target = [];
    }

    /**
     * Get SQL join to restrict by profile and by config to avoid send notification
     * to a user without rights.
     *
     * @return array
     */
    public function getProfileJoinCriteria()
    {
        $criteria = [
            'INNER JOIN'   => [
                Profile_User::getTable() => [
                    'ON' => [
                        Profile_User::getTable()   => 'users_id',
                        User::getTable()           => 'id',
                    ],
                ],
            ],
            'WHERE' => getEntitiesRestrictCriteria(
                Profile_User::getTable(),
                'entities_id',
                $this->getEntity(),
                true
            ),
        ];

        if ($this->isTargetItemRecursive()) {
            $criteria['WHERE'] = [
                'OR' => [
                    $criteria['WHERE'],
                    [
                        Profile_User::getTableField('entities_id') => getSonsOf(Entity::getTable(), $this->getEntity()),
                    ],
                ],
            ];
        }

        return $criteria;
    }


    /**
     * @param string|null $event
     * @param array       $options
     *
     * @return array<string, string|array<string>>
     **/
    public function &getForTemplate($event, $options)
    {
        $this->data = [];
        $this->addDataForTemplate($event, $options);

        // Add global tags data, use `+` operator to preserve overriden values
        $this->data += $this->getGlobalTagsData();

        if (isset($options['additionnaloption']['users_id'])) {
            // Store current user info for plugins to access during ITEM_GET_DATA hook
            $this->recipient_data = [
                'itemtype' => User::class,
                'items_id' => $options['additionnaloption']['users_id'],
            ];
        }
        Plugin::doHook(Hooks::ITEM_GET_DATA, $this);
        $this->recipient_data = [];

        return $this->data;
    }

    /**
     * Register global tags.
     *
     * @return void
     */
    private function registerGlobalTags(): void
    {
        $this->addTagToList([
            'tag'   => 'glpi.url',
            'value' => true,
            'label' => __('URL of the application'),
            'lang'  => false,
        ]);
    }

    /**
     * Define global tags data.
     *
     * @return array<string, string>
     */
    private function getGlobalTagsData(): array
    {
        return [
            '##glpi.url##' => $this->getUrlBase(),
        ];
    }

    /**
     * @return string[]|string[][]|void
     */
    public function getTags()
    {
        return $this->tag_descriptions;
    }

    /**
     * @param array{
     *   tag?: string|false,
     *   value?: bool,
     *   label?: string|false,
     *   events?: array<string>|self::TAG_FOR_ALL_EVENTS,
     *   foreach?: bool,
     *   lang?: bool,
     *   allowed_values?: array
     * } $options
     *
     * @return void
     **/
    public function addTagToList($options = [])
    {
        $p['tag']            = false;
        $p['value']          = true;
        $p['label']          = false;
        $p['events']         = self::TAG_FOR_ALL_EVENTS;
        $p['foreach']        = false;
        $p['lang']           = true;
        $p['allowed_values'] = [];

        foreach ($options as $key => $value) {
            $p[$key] = $value;
        }

        if ($p['tag']) {
            if (is_array($p['events'])) {
                $events = $this->getAllEvents();
                $tmp = [];

                foreach ($p['events'] as $event) {
                    $tmp[$event] = $events[$event];
                }

                $p['events'] = $tmp;
            }

            if ($p['foreach']) {
                $tag = "##FOREACH" . $p['tag'] . "## ##ENDFOREACH" . $p['tag'] . "##";
                $this->tag_descriptions[self::TAG_VALUE][$tag] = $p;
                $tag = "##FOREACH FIRST <number> " . $p['tag'] . "## ##ENDFOREACH" . $p['tag'] . "##";
                $this->tag_descriptions[self::TAG_VALUE][$tag] = $p;
                $tag = "##FOREACH LAST <number> " . $p['tag'] . "## ##ENDFOREACH" . $p['tag'] . "##";
                $this->tag_descriptions[self::TAG_VALUE][$tag] = $p;
            } else {
                if ($p['value']) {
                    $tag = "##" . $p['tag'] . "##";
                    $this->tag_descriptions[self::TAG_VALUE][$tag] = $p;
                }

                if ($p['label'] && $p['lang']) {
                    $tag = "##lang." . $p['tag'] . "##";
                    $this->tag_descriptions[self::TAG_LANGUAGE][$tag] = $p;
                }
            }
        }
    }

    #[Override]
    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {

        if (!$withtemplate && Notification::canView()) {
            $nb = 0;
            switch (get_class($item)) {
                case Group::class:
                    if ($_SESSION['glpishow_count_on_tabs']) {
                        $nb = self::countForGroup($item);
                    }
                    return self::createTabEntry(
                        Notification::getTypeName(Session::getPluralNumber()),
                        $nb,
                        $item::class
                    );

                case Notification::class:
                    if ($_SESSION['glpishow_count_on_tabs']) {
                        $nb = countElementsInTable(
                            static::getTable(),
                            ['notifications_id' => $item->getID()]
                        );
                    }
                    return self::createTabEntry(self::getTypeName(Session::getPluralNumber()), $nb, $item::class);
            }
        }
        return '';
    }


    /**
     * Count Notification for a group
     *
     * @since 0.83
     *
     * @param $group Group object
     *
     * @return int
     **/
    public static function countForGroup(Group $group)
    {
        global $DB;

        $count = $DB->request([
            'COUNT'        => 'cpt',
            'FROM'         => self::getTable(),
            'INNER JOIN'   => [
                Notification::getTable()   => [
                    'ON'  => [
                        Notification::getTable()   => 'id',
                        self::getTable()           => 'notifications_id',
                    ],
                ],
            ],
            'WHERE'        => [
                'type'      => [
                    Notification::SUPERVISOR_GROUP_TYPE,
                    Notification::GROUP_TYPE,
                ],
                'items_id'  => $group->getID(),
                'is_exclusion' => 0,
            ] + getEntitiesRestrictCriteria(Notification::getTable(), '', '', true),
        ])->current();
        return $count['cpt'];
    }


    /**
     * Display notification registered for a group
     *
     * @since 0.83
     *
     * @param $group Group object
     *
     * @return bool
     **/
    public static function showForGroup(Group $group): bool
    {
        global $DB;

        if (!Notification::canView()) {
            return false;
        }

        $iterator = $DB->request([
            'SELECT'       => [Notification::getTable() . '.id'],
            'FROM'         => self::getTable(),
            'INNER JOIN'   => [
                Notification::getTable() => [
                    'ON' => [
                        self::getTable()           => 'notifications_id',
                        Notification::getTable()   => 'id',
                    ],
                ],
            ],
            'WHERE'        => [
                'type'      => [
                    Notification::SUPERVISOR_GROUP_TYPE,
                    Notification::GROUP_TYPE,
                ],
                'items_id'  => $group->getID(),
                'is_exclusion' => 0,
            ] + getEntitiesRestrictCriteria(Notification::getTable(), '', '', true),
        ]);

        $notifications = [];
        if (count($iterator)) {
            Session::initNavigateListItems(
                'Notification',
                //TRANS : %1$s is the itemtype name, %2$s is the name of the item (used for headings of a list)
                sprintf(
                    __('%1$s = %2$s'),
                    Group::getTypeName(1),
                    $group->getName()
                )
            );

            foreach ($iterator as $data) {
                Session::addToNavigateListItems('Notification', $data['id']);
                $notif = new Notification();
                if ($notif->getFromDB($data['id'])) {
                    $notifications[] = $notif;
                }
            }
        }
        TemplateRenderer::getInstance()->display('pages/setup/notification/group_notifications.html.twig', [
            'notifications' => $notifications,
        ]);

        return true;
    }


    #[Override]
    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0)
    {
        if (!$item instanceof CommonDBTM) {
            return false;
        }

        if ($item instanceof Group) {
            return self::showForGroup($item);
        } elseif ($item instanceof Notification) {
            /** @var class-string<CommonGLPI> $itemtype */
            $itemtype = $item->fields['itemtype'];

            $target = self::getInstanceByType(
                $itemtype,
                $item->fields['event'],
                ['entities_id' => $item->fields['entities_id']]
            );
            if ($target) {
                return $target->showForNotification($item);
            }
        }
        return false;
    }

    /**
     * Set mode
     *
     * @param string $mode Mode (see Notification_NotificationTemplate::MODE_*)
     *
     * @return static
     */
    public function setMode($mode)
    {
        $this->mode = $mode;
        return $this;
    }

    /**
     * Get mode
     *
     * @return string
     */
    public function getMode()
    {
        return $this->mode;
    }

    /**
     * Is current mode for mail
     *
     * @return bool
     */
    protected function isMailMode()
    {
        return ($this->mode == Notification_NotificationTemplate::MODE_MAIL);
    }

    /**
     * Set event
     *
     * @param string $event Event class
     *
     * @return static
     */
    public function setEvent($event)
    {
        $this->event = $event;
        return $this;
    }


    /**
     * Get the value of allow_response
     *
     * @return bool
     */
    public function allowResponse()
    {
        return $this->allow_response;
    }

    /**
     * Set the value of allow_response
     *
     * @param bool $allow_response
     *
     * @return static
     */
    public function setAllowResponse($allow_response)
    {
        $this->allow_response = $allow_response;

        return $this;
    }

    /**
     * Check if at least one target item is recursive
     *
     * @return bool
     */
    protected function isTargetItemRecursive(): bool
    {
        // If the notification target more than one item, we can't handle the
        // entity restriction correctly and must discard any potential child
        // entities check
        if (count($this->target_object) > 1) {
            return false;
        }

        // Not all items support recursion
        if (!($this->obj instanceof CommonDBTM)  || !$this->obj->maybeRecursive()) {
            return false;
        }

        return $this->obj->isRecursive();
    }
}
