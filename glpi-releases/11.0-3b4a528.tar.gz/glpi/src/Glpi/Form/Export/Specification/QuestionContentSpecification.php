<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2026 Teclib' and contributors.
 * @copyright 2003-2014 by the INDEPNET Development Team.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

namespace Glpi\Form\Export\Specification;

final class QuestionContentSpecification implements ContentSpecificationInterface
{
    public int $id;
    public string $uuid;
    public string $name;
    public string $type;
    public bool $is_mandatory;
    public int $vertical_rank;
    public ?int $horizontal_rank = null;
    public ?string $description = null;
    public mixed $default_value;
    public ?array $extra_data = null;
    public int $section_id;
    public string $visibility_strategy;
    public string $validation_strategy;

    /** @var ConditionDataSpecification[] $conditions */
    public array $conditions;
    /** @var ConditionDataSpecification[] $validation_conditions */
    public array $validation_conditions;

}
