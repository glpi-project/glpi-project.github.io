<?php

/**
 * ---------------------------------------------------------------------
 *
 * GLPI - Gestionnaire Libre de Parc Informatique
 *
 * http://glpi-project.org
 *
 * @copyright 2015-2026 Teclib' and contributors.
 * @licence   https://www.gnu.org/licenses/gpl-3.0.html
 *
 * ---------------------------------------------------------------------
 *
 * LICENSE
 *
 * This file is part of GLPI.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * ---------------------------------------------------------------------
 */

namespace Glpi\Form;

enum RenderLayout: string
{
    case STEP_BY_STEP = 'step_by_step';
    case SINGLE_PAGE  = 'single_page';

    public function getLabel(): string
    {
        return match ($this) {
            self::STEP_BY_STEP => __('Section by section'),
            self::SINGLE_PAGE  => __('Single page'),
        };
    }

    public function getIcon(): string
    {
        return match ($this) {
            self::STEP_BY_STEP => 'ti ti-layout-distribute-vertical',
            self::SINGLE_PAGE  => 'ti ti-layout-distribute-horizontal',
        };
    }
}
